import SwiftUI

@main
struct KEVAApp: App {
    var body: some Scene {
        WindowGroup { ContentView().preferredColorScheme(.dark) }
    }
}

struct ContentView: View {
    @State private var password = ""
    @State private var unlocked = false
    @State private var error = false

    var body: some View {
        if unlocked {
            MainMenuView()
        } else {
            ZStack {
                Color.black.ignoresSafeArea()
                VStack(spacing: 22) {
                    Spacer()
                    Image(systemName: "crown.fill")
                        .font(.system(size: 54)).foregroundStyle(.red)
                        .shadow(color: .red.opacity(0.8), radius: 18)
                    Text("KEVA").font(.system(size: 38, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("ENTER PASSWORD").font(.caption.weight(.bold))
                        .tracking(3).foregroundStyle(.red)
                    SecureField("Password", text: $password)
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                        .padding(16).background(Color.white.opacity(0.07))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(.red.opacity(0.7)))
                        .padding(.horizontal, 28)
                    if error { Text("Wrong password").font(.footnote.weight(.semibold)).foregroundStyle(.red) }
                    Button {
                        if password == "KEVAX" { unlocked = true; error = false }
                        else { error = true }
                    } label: {
                        Text("UNLOCK").font(.headline.weight(.black)).tracking(2)
                            .foregroundStyle(.white).frame(maxWidth: .infinity).padding(16)
                            .background(LinearGradient(colors: [.red, Color(red: 0.45, green: 0, blue: 0)], startPoint: .top, endPoint: .bottom))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }.padding(.horizontal, 28)
                    Spacer()
                    Text("MADE BY KEVA").font(.caption2.weight(.bold)).tracking(2)
                        .foregroundStyle(.gray).padding(.bottom, 18)
                }
            }
        }
    }
}

struct MainMenuView: View {
    @State private var tab = "ESP"
    @State private var enableESP = true
    @State private var lineESP = true
    @State private var boxESP = true
    @State private var healthESP = false
    @State private var showCount = false
    @State private var notifications = true
    @State private var compactMode = false
    private let red = Color(red: 1, green: 0.04, blue: 0.08)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 18) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("KEVA").font(.system(size: 32, weight: .black, design: .rounded)).foregroundStyle(.white)
                        Text("ADMIN : @keva").font(.caption.weight(.bold)).foregroundStyle(red)
                    }
                    Spacer()
                    Image(systemName: "crown.fill").font(.system(size: 28)).foregroundStyle(red)
                }.padding(.horizontal)
                HStack(spacing: 10) {
                    ForEach(["ESP", "AIMBOT", "OTHER"], id: \.self) { item in
                        Button { tab = item } label: {
                            Text(item).font(.subheadline.weight(.black)).frame(maxWidth: .infinity).padding(.vertical, 14)
                                .foregroundStyle(tab == item ? .white : .gray)
                                .background(tab == item ? red : Color.white.opacity(0.06))
                                .clipShape(Capsule())
                        }
                    }
                }.padding(.horizontal)
                VStack(spacing: 0) {
                    HStack {
                        Text(tab).font(.headline.weight(.black)).foregroundStyle(red)
                        Spacer()
                        Text("KEVA MENU").font(.caption2.weight(.bold)).foregroundStyle(.gray)
                    }.padding(16)
                    if tab == "ESP" {
                        toggleRow("Enable Esp", $enableESP)
                        toggleRow("Line Esp", $lineESP)
                        toggleRow("Box Esp", $boxESP)
                        toggleRow("Health Esp", $healthESP)
                        toggleRow("Show Count", $showCount)
                    } else if tab == "AIMBOT" {
                        infoRow("AIMBOT", "Visual menu placeholder only; no game automation is included.")
                    } else {
                        toggleRow("Notifications", $notifications)
                        toggleRow("Compact Mode", $compactMode)
                        infoRow("About", "Made by KEVA")
                    }
                }
                .background(Color(white: 0.055))
                .clipShape(RoundedRectangle(cornerRadius: 22))
                .overlay(RoundedRectangle(cornerRadius: 22).stroke(red.opacity(0.75), lineWidth: 1.5))
                .shadow(color: red.opacity(0.22), radius: 16)
                .padding(.horizontal)
                Spacer(minLength: 4)
                Text("Made by keva").font(.footnote.weight(.bold)).foregroundStyle(red)
                HStack {
                    Label("Home", systemImage: "house.fill")
                    Spacer()
                    Label("Info", systemImage: "info.circle.fill")
                    Spacer()
                    Label("varClean", systemImage: "trash.fill")
                }.font(.caption.weight(.semibold)).foregroundStyle(.gray).padding(.horizontal, 30).padding(.bottom, 8)
            }.padding(.top, 18)
        }
    }

    private func toggleRow(_ title: String, _ value: Binding<Bool>) -> some View {
        Toggle(title, isOn: value).tint(red).foregroundStyle(.white)
            .padding(.horizontal, 16).padding(.vertical, 12)
        // UI preferences only; these switches do not control a game.
    }

    private func infoRow(_ title: String, _ detail: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.body.weight(.bold)).foregroundStyle(.white)
            Text(detail).font(.caption).foregroundStyle(.gray)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(16)
    }
}
