# KEVA iOS project

This repository builds a **visual-only** SwiftUI app shell for iOS 16+.
It includes a KEVA black/red interface, a demo password screen (`KEVAX`),
and ESP / AIMBOT / OTHER tabs with local UI toggles. It does not implement
game cheats, game injection, memory modification, anti-cheat bypass, or aiming automation.

## Build from GitHub on iPhone

1. Create a GitHub repository named `KEVA-App`.
2. In the repository, choose **Add file → Upload files**.
3. Upload the contents of this folder (including the hidden `.github` folder).
4. Commit to the `main` branch.
5. Open the **Actions** tab and select **Build KEVA TIPA**.
6. If it has not run automatically, tap **Run workflow**.
7. When the run finishes successfully, open it and download the `KEVA-TIPA` artifact.
8. Extract the downloaded artifact ZIP to get `KEVA.tipa`, then try installing it with TrollStore.

Notes:
- GitHub Actions builds on a hosted macOS runner; no Mac is needed locally.
- This workflow is a best-effort unsigned package. TrollStore compatibility can depend
  on the device, bundle metadata, and packaging. If installation fails, share the exact
  error screenshot.
- The password is hard-coded for demonstration and is not secure authentication.
